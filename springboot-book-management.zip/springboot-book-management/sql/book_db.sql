-- 创建数据库（如果不存在）
CREATE DATABASE IF NOT EXISTS book_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 使用数据库
USE book_db;

-- 创建图书表
DROP TABLE IF EXISTS book;
CREATE TABLE book (
                      id BIGINT AUTO_INCREMENT COMMENT '图书ID' PRIMARY KEY,
                      name VARCHAR(100) NOT NULL COMMENT '书名',
                      author VARCHAR(50) NOT NULL COMMENT '作者',
                      type VARCHAR(20) DEFAULT '其他' COMMENT '图书类型',
                      status VARCHAR(20) DEFAULT '可借阅' COMMENT '借阅状态',
                      create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                      update_time DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'
) COMMENT '图书信息表';

-- 插入测试数据
INSERT INTO book (name, author, type, status) VALUES
                                                  ('Java核心技术 卷1', 'Cay S. Horstmann', '技术', '可借阅'),
                                                  ('Spring Boot实战', 'Craig Walls', '技术', '已借出'),
                                                  ('三体', '刘慈欣', '小说', '可借阅'),
                                                  ('时间简史', '霍金', '科普', '可借阅'),
                                                  ('Python编程：从入门到实践', '埃里克·马瑟斯', '技术', '已借出');

-- 查询数据
SELECT * FROM book;