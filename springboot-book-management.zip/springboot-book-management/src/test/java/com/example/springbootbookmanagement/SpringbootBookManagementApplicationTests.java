package com.example.springbootbookmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootBookManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
