package com.example.controller;

import com.example.entity.Book;
import com.example.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 * 图书控制器（处理页面请求）
 */
@Controller
public class BookController {

    @Autowired
    private BookService bookService;

    /**
     * 图书列表页
     */
    @GetMapping("/")
    public String list(Model model) {
        model.addAttribute("books", bookService.findAll());
        return "list";
    }

    /**
     * 搜索图书
     */
    /**
     * 搜索图书（兼容空关键词）
     */
    @GetMapping("/search")
    public String search(
            @RequestParam(required = false) String keyword,  // 设置为非必填
            Model model
    ) {
        // 1. 处理空关键词：如果关键词为空/空格，返回全部图书
        if (keyword == null || keyword.trim().isEmpty()) {
            model.addAttribute("books", bookService.findAll());
        } else {
            // 2. 关键词非空：执行模糊搜索
            String searchKeyword = keyword.trim(); // 去除首尾空格
            model.addAttribute("books", bookService.search(searchKeyword));
            model.addAttribute("keyword", searchKeyword); // 回显搜索框关键词
        }
        return "list"; // 跳回列表页展示结果
    }

    /**
     * 跳转到添加/编辑页面
     */
    @GetMapping("/book/form")
    public String form(@RequestParam(required = false) Long id, Model model) {
        if (id != null) {
            // 编辑：回显数据
            model.addAttribute("book", bookService.findById(id));
        } else {
            // 新增：空对象
            model.addAttribute("book", new Book());
        }
        return "form";
    }

    /**
     * 保存图书（新增/修改）
     */
    @PostMapping("/book/save")
    public String save(Book book, RedirectAttributes redirectAttributes) {
        boolean success = bookService.save(book);
        if (success) {
            redirectAttributes.addFlashAttribute("msg", "操作成功！");
        } else {
            redirectAttributes.addFlashAttribute("msg", "操作失败！");
        }
        return "redirect:/"; // 重定向回列表页
    }

    /**
     * 删除图书
     */
    @GetMapping("/book/delete/{id}")
    public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        boolean success = bookService.delete(id);
        if (success) {
            redirectAttributes.addFlashAttribute("msg", "删除成功！");
        } else {
            redirectAttributes.addFlashAttribute("msg", "删除失败！");
        }
        return "redirect:/";
    }
}