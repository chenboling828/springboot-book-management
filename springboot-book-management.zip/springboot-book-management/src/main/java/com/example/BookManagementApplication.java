package com.example;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 图书管理系统启动类
 */
@SpringBootApplication
@MapperScan("com.example.mapper")  // 扫描 Mapper 接口
public class BookManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookManagementApplication.class, args);
        System.out.println("=====================================");
        System.out.println("✅ 图书管理系统启动成功！访问：http://localhost:8080");
        System.out.println("=====================================");
    }

}