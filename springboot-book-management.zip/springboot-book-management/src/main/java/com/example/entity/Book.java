package com.example.entity;

import lombok.Data;

/**
 * 图书实体类
 */
@Data  // Lombok 自动生成 getter/setter/toString 等方法
public class Book {
    /**
     * 图书ID
     */
    private Long id;
    /**
     * 书名
     */
    private String name;
    /**
     * 作者
     */
    private String author;
    /**
     * 图书类型（小说/技术/科普/其他）
     */
    private String type;
    /**
     * 借阅状态（可借阅/已借出）
     */
    private String status;
}