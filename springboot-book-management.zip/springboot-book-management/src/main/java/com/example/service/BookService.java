package com.example.service;

import com.example.entity.Book;

import java.util.List;

/**
 * 图书业务层接口
 */
public interface BookService {

    /**
     * 查询所有图书
     */
    List<Book> findAll();

    /**
     * 根据ID查询图书
     */
    Book findById(Long id);

    /**
     * 保存图书（新增/修改）
     */
    boolean save(Book book);

    /**
     * 删除图书
     */
    boolean delete(Long id);

    /**
     * 模糊搜索
     */
    List<Book> search(String keyword);
}