package com.example.service.impl.impl;

import com.example.entity.Book;
import com.example.mapper.BookMapper;
import com.example.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 图书业务层实现
 */
@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookMapper bookMapper;

    @Override
    public List<Book> findAll() {
        return bookMapper.findAll();
    }

    @Override
    public Book findById(Long id) {
        return bookMapper.findById(id);
    }

    @Override
    public boolean save(Book book) {
        int result;
        if (book.getId() == null || book.getId() == 0) {
            // 新增
            result = bookMapper.insert(book);
        } else {
            // 修改
            result = bookMapper.update(book);
        }
        return result > 0;
    }

    @Override
    public boolean delete(Long id) {
        return bookMapper.delete(id) > 0;
    }

    @Override
    public List<Book> search(String keyword) {
        return bookMapper.search(keyword);
    }
}