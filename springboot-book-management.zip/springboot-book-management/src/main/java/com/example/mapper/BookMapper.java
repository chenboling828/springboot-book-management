package com.example.mapper;

import com.example.entity.Book;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 图书数据访问层
 */
@Mapper
public interface BookMapper {

    /**
     * 查询所有图书
     */
    List<Book> findAll();

    /**
     * 根据ID查询图书
     */
    Book findById(Long id);

    /**
     * 添加图书
     */
    int insert(Book book);

    /**
     * 修改图书
     */
    int update(Book book);

    /**
     * 删除图书
     */
    int delete(Long id);

    /**
     * 模糊搜索（书名/作者）
     */
    List<Book> search(String keyword);
}